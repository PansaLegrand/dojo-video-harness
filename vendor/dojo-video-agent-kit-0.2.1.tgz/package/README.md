# Editor agent kit

One portable catalog of editor tool metadata, capability-gated skills and prompt
sections. Trusted host ports supply inspection, graphics preparation and native
proposal/clarification validation. The kit never imports the editing kernel,
engine, database, provider SDK, credit ledger or filesystem at runtime.

Canonical built-in instructions live in the harness's `skills/*.md`. The build
embeds a checked snapshot for standalone consumers. Local hosts retain their
bounded Markdown loader and `SKILLS_DIR`; custom skills cannot install executors.
Conditional `requires-tool` sections appear only when that tool is registered.

`createEditorToolset` returns executable tools, eligible skills and a serializable
inventory from the same registered executors. Hosts may add explicit external
action tools. Portable preparation tools have no permission to spend or commit.
The frozen commercial-editing-v2 profile preserves eight tools/two named skills; the full local host
adds text-overlay preparation and its music/workflow services. Those services
retain their own approval, job and persistence lifecycles.

`composeToolAgentPrompt` accepts an editing guide already generated in tool mode;
it does not patch or search/replace host instructions. Run the same conformance
fixtures in each host before moving command semantics into shared packages.

Kit0.1.2 adds local-editor-v2/commercial-editing-v3 profiles. Their review_edit
tool freezes a first valid typed checklist, returns pinned failure/success
observations and permits propose_edit only for exact successfully reviewed
commands. Trusted host ports supply native compilation and bounded layout checks;
the kit does not render or commit. Host-generated deterministic completion
receipts travel with new editing results for independent replay. Existing profile
inventory versions, tool schemas/guidance and eligible skills remain frozen.

restoreCompletionStateFromMessages reconstructs private executor state only from
validated checkpoint tool messages. Supply it as initialCompletionState (with
snapshotHash) when creating a new session. Pure prepare_caption_pair is optional
and host-owned; its translations bind exact genuine cue IDs/timing without a new
provider call. A checklist proves declared outcomes, not universal task semantics.

Kit 0.1.3 adds local-editor-v3/commercial-editing-v4. The host supplies
`listAssets` and `readCaptionCues` ports for snapshot-bound, byte-bounded readers.
Asset queries discover unused imported assets with stable IDs and registration
status. Cue queries preserve complete host-derived cue and source-word identity.
Both readers return explicit coverage and cursor metadata. Their observations
are pinned and may replay through a host-declared safe snapshot executor.

The new profiles also support `asset_sequence` requirements for exact grouped
media placements, `speech_callout` requirements for genuine quoted words, and an
optional sourceRange on cue reading/caption preparation. Source-range projection
belongs to the host kernel and returns source trim commands alongside captions.
Earlier profiles retain their prior schema, inventory version, skills and prompts.

Kit 0.1.4 adds local-editor-v4/commercial-editing-v5. These profiles prioritize
authoritative supplied metadata and targeted discovery of the requested sources.
Hosts pass profile to composeToolAgentPrompt to select that guidance. Reader
snapshotHash is optional at the model boundary and resolves to the host's frozen
snapshot, while a supplied mismatch fails. Underlying reader ports receive the
same explicit snapshot binding.

Kit 0.1.3 built-in guidance is retained for its older profiles, with regression
digests covering inventory, skill text and prompt bytes. Current canonical skills
continue in skills/\*.md. Host-owned new-profile execution defaults can use sixteen
model steps while retaining existing tool/output allowances and accepted-run budgets.

Kit 0.1.5 adds local-editor-v5/commercial-editing-v6. Both editing tools advertise
proposal-only, nonempty command schemas. review_edit rebases all embedded local
references under its edit property; propose_edit retains valid root references.
Requirements remain frozen while command batches remain repairable. Model reader
schemas omit snapshotHash entirely and the host binds it internally. Initial
caption context is an overview; exact requested-range cues are read before translation.
Earlier 0.1.4 guidance/schemas remain frozen for its profiles.

The 0.2 source-clock boundary exports `sourceClockWindow` and
`projectSourceClockRange` for already validated timeline data. The structural
numeric module has no host or renderer dependencies. The accompanying version-1
conformance corpus checks both host kernels, including source/evidence preservation,
scope, rebase, selective Undo and segmentation receipts. See
[`docs/semantic-conformance.md`](../../docs/semantic-conformance.md) for the exact
fixture boundary, intentional host differences and reference-update policy.

Kit 0.2 adds `local-editor-v6` / `commercial-editing-v7`. The portable
`runEditingStages` coordinator persists dependencies, immutable artifacts, absolute
usage and one final reviewed candidate. The standard policy allows 32 model calls,
64 tool calls and 32,000 output tokens for the original request, with a 16-call
planning phase, 100-cue caption batches and 8/24/16,000 per later invocation.
Hosts atomically save each checkpoint with its absolute usage. Questions, source
inspection and approved external jobs pause that same funded request; they do not
reset its allowance. Source/model/scope changes fail closed before further model
work. The original instruction and completed artifacts remain reusable.

`createEditorHostTools` registers only supplied trusted ports in these new profiles.
Image/frame inspection, saved visual retrieval, generation quotes and browser
preview/export are contracts, not built-in cloud services. Their two conditional
skills load only when the required executors exist. Credentials, ownership,
consent, prices, provider submission, storage and application stay in each host.
The local harness does not advertise commercial HTTP adapters it does not own.
A preview is not a general autonomous visual-repair guarantee.

See [the host adapter contract](../../docs/staged-editing-host-api.md) for CAS,
canonical JSON, float-preserving storage, continuation and receipt boundaries.
